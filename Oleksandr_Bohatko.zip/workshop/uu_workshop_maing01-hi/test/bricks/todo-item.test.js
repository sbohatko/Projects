import UU5 from "uu5g04";
import UuWorkshop from "uu_workshop_maing01-hi";

const { shallow } = UU5.Test.Tools;

describe(`UuWorkshop.Bricks.TodoItem`, () => {
  it(`default props`, () => {
    const wrapper = shallow(<UuWorkshop.Bricks.TodoItem />);
    expect(wrapper).toMatchSnapshot();
  });
});
