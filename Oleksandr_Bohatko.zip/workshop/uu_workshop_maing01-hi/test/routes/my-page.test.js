import UU5 from "uu5g04";
import UuWorkshop from "uu_workshop_maing01-hi";

const { shallow } = UU5.Test.Tools;

describe(`UuWorkshop.Routes.MyPage`, () => {
  it(`default props`, () => {
    const wrapper = shallow(<UuWorkshop.Routes.MyPage />);
    expect(wrapper).toMatchSnapshot();
  });
});
