//@@viewOn:imports
import UU5 from "uu5g04";
import { createVisualComponent, useEffect, useCall, useDataList } from "uu5g04-hooks";
import Config from "./config/config";
import Calls from "../calls";
import JokeItem from "../bricks/joke-item";
//@@viewOff:imports

const STATICS = {
  //@@viewOn:statics
  displayName: Config.TAG + "JokesList",
  nestingLevel: "bigBoxCollection",
  //@@viewOff:statics
};

export const JokesList = createVisualComponent({
  ...STATICS,

  //@@viewOn:propTypes
  propTypes: {},
  //@@viewOff:propTypes

  //@@viewOn:defaultProps
  defaultProps: {},
  //@@viewOff:defaultProps

  render(props) {
    //@@viewOn:private
    const dataListResult = useDataList({
      handlerMap: {
        load: Calls.listJokes,
        createItem: Calls.createJoke,
      },
      itemHandlerMap: {
        load: Calls.getJoke,
        update: Calls.updateJoke,
        delete: Calls.deleteJoke,
      },
    });
    const { state, data, newData, errorData, pendingData, handlerMap } = dataListResult;
    console.log(dataListResult);

    // useEffect(() => {
    //   call();
    // }, []);
    //@@viewOff:private

    //@@viewOn:interface
    //@@viewOff:interface

    //@@viewOn:render

    const className = Config.Css.css``;
    const attrs = UU5.Common.VisualComponent.getAttrs(props, className);
    const currentNestingLevel = UU5.Utils.NestingLevel.getNestingLevel(props, STATICS);

    return currentNestingLevel ? (
      <div {...attrs}>
        <div>Visual Component {STATICS.displayName}</div>
        {UU5.Utils.Content.getChildren(props.children, props, STATICS)}
        {data?.map((item, i) => (
          <JokeItem joke={item.data} key={i} />
        ))}
      </div>
    ) : null;
    //@@viewOff:render
  },
});

export default JokesList;
