//@@viewOn:imports
import UU5 from "uu5g04";
import { createVisualComponent, useEffect, useCall, useDataList } from "uu5g04-hooks";
import Config from "./config/config";
import Calls from "../calls";
import TodoItem from "../bricks/todo-item";

//@@viewOff:imports

const STATICS = {
  //@@viewOn:statics
  displayName: Config.TAG + "TodoList",
  nestingLevel: "bigBoxCollection",
  //@@viewOff:statics
};

function filterItems(items, id){
  items.forEach(element => {
    if(element !== id){
      delete element;
    }
  });
  return items;
}

export const TodoList = createVisualComponent({
  ...STATICS,

  //@@viewOn:propTypes
  propTypes: {},
  //@@viewOff:propTypes

  //@@viewOn:defaultProps
  defaultProps: {},
  //@@viewOff:defaultProps

  render(props) {
    const dataListResult = useDataList({
      handlerMap: {
        load: Calls.listItem,
        createItem: Calls.createItem,
      },
      itemHandlerMap: {
        load: Calls.getItem,
        update: Calls.updateItem,
        delete: Calls.deleteItem,
        delete: Calls.completeItem,
      },
    });
    const { state, data, newData, errorData, pendingData, handlerMap } = dataListResult;
    // console.log(dataListResult);
    //@@viewOn:private
    //@@viewOff:private

    //@@viewOn:interface
    //@@viewOff:interface

    //@@viewOn:render
    const className = Config.Css.css``;
    const attrs = UU5.Common.VisualComponent.getAttrs(props, className);
    const currentNestingLevel = UU5.Utils.NestingLevel.getNestingLevel(props, STATICS);

    return currentNestingLevel ? (
      <div {...attrs}>
        <div>Visual Component {STATICS.displayName}</div>
        {UU5.Utils.Content.getChildren(props.children, props, STATICS)}
        {data?.map((item, i) => (
          <TodoItem joke={item.data} key={i} />
        ))}
      </div>
    ) : null;
    //@@viewOff:render
  },
});

export default TodoList;
