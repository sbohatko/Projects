//@@viewOn:imports
import UU5 from "uu5g04";
import { createVisualComponent } from "uu5g04-hooks";
import Config from "./config/config";
//@@viewOff:imports

const joke = () => Config.Css.css`
  color: green;
`;

const jokeWrap = () => Config.Css.css`
  background-color: lightgrey;
  padding: 1em;
  margin: 1em;
`;

const STATICS = {
  //@@viewOn:statics
  displayName: Config.TAG + "JokeItem",
  nestingLevel: "bigBoxCollection",
  //@@viewOff:statics
};

export const JokeItem = createVisualComponent({
  ...STATICS,

  //@@viewOn:propTypes
  propTypes: {},
  //@@viewOff:propTypes

  //@@viewOn:defaultProps
  defaultProps: {},
  //@@viewOff:defaultProps

  render(props) {
    //@@viewOn:private
    //@@viewOff:private

    //@@viewOn:interface
    //@@viewOff:interface

    //@@viewOn:render
    const className = Config.Css.css``;
    const attrs = UU5.Common.VisualComponent.getAttrs(props, className);
    const currentNestingLevel = UU5.Utils.NestingLevel.getNestingLevel(props, STATICS);
    const { name, text } = props.joke;

    return currentNestingLevel ? (
      <div {...attrs}>
        <div>Visual Component {STATICS.displayName}</div>
        {UU5.Utils.Content.getChildren(props.children, props, STATICS)}
        <div className={jokeWrap()}>
          <div className={joke()}>
            <h3>{name}</h3>
            <p>{text}</p>
          </div>
        </div>
      </div>
    ) : null;
    //@@viewOff:render
  },
});

export default JokeItem;
