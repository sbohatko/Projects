const { TestHelper } = require("uu_appg01_server-test");

const useCase = "list/delete";

beforeAll(async () => {
  await TestHelper.setup();
  await TestHelper.initUuSubAppInstance();
  await TestHelper.createUuAppWorkspace();
  await TestHelper.initUuAppWorkspace({ uuAppProfileAuthorities: "urn:uu:GGPLUS4U" });
});

afterAll(async () => {
  await TestHelper.teardown();
});

describe(`Testing ${useCase} uuCmd...`, () => {
  test("HDS - SHO TAM", async () => {
    const dtoIn = {
      name: "new name",
    };

    let list = await TestHelper.executePostCommand("list/create", dtoIn);
    const result = await TestHelper.executePostCommand(useCase, { id: list.data.id });

    expect(result.status).toEqual(200);
    expect(result.data.uuAppErrorMap).toBeDefined();
  });

  test("unsupported keys", async () => {
    const dtoIn = {
      forceDelete: false,
      anyKey: "??????",
    };

    const errorCode = `uu-todo-main/${useCase}/unsupportedKeys`;

    let list = await TestHelper.executePostCommand("list/create", { name: "new name" });
    const result = await TestHelper.executePostCommand(useCase, { id: list.data.id, ...dtoIn });

    expect(result.status).toEqual(200);
    expect(result.data.uuAppErrorMap).toBeDefined();
    expect(result.data.uuAppErrorMap[errorCode]).toBeDefined();
  });

  test("Invalid DtoIn", async () => {
    expect.assertions(3);
    const errorCode = `uu-todo-main/${useCase}/invalidDtoIn`;
    const dtoIn = {
      id: "sss",
    };

    try {
      await TestHelper.executePostCommand(useCase, dtoIn);
    } catch (e) {
      expect(e.status).toEqual(400);
      expect(e.code).toEqual(errorCode);
      expect(e.dtoOut.uuAppErrorMap).toBeDefined();
    }
  });
  test("List does not exist", async () => {
    expect.assertions(3);
    const dtoIn = {
      id: "60e344c9481a5a2ce8401f55",
    };

    const errorCode = `uu-todo-main/${useCase}/listDoesNotExist`;

    try {
      await TestHelper.executePostCommand(useCase, dtoIn);
    } catch (e) {
      expect(e.status).toEqual(400);
      expect(e.code).toEqual(errorCode);
      expect(e.dtoOut.uuAppErrorMap).toBeDefined();
    }
  });
});
