const { TestHelper } = require("uu_appg01_server-test");

const useCase = "item/create";

beforeAll(async () => {
  await TestHelper.setup();
  await TestHelper.initUuSubAppInstance();
  await TestHelper.createUuAppWorkspace();
  await TestHelper.initUuAppWorkspace({ uuAppProfileAuthorities: "urn:uu:GGPLUS4U" });
});

afterAll(async () => {
  await TestHelper.teardown();
});

describe(`Testing ${useCase} uuCmd...`, () => {
  test("HDS - SHO TAM", async () => {
    let list = await TestHelper.executePostCommand("list/create", { name: "some name" });
    const result = await TestHelper.executePostCommand(useCase, { listId: list.data.id, text: "some text" });

    expect(result.status).toEqual(200);
    expect(result.data.uuAppErrorMap).toBeDefined();
  });

  test("unsupported keys", async () => {
    const errorCode = `uu-todo-main/${useCase}/unsupportedKeys`;
    const dtoIn = {
      text: "some text",
      someKey: "some value",
    };
    let list = await TestHelper.executePostCommand("list/create", { name: "some name" });
    const result = await TestHelper.executePostCommand(useCase, { listId: list.data.id, ...dtoIn });

    expect(result.status).toEqual(200);
    expect(result.data.uuAppErrorMap).toBeDefined();
    expect(result.data.uuAppErrorMap[errorCode]).toBeDefined();
  });

  test("Invalid DtoIn", async () => {
    expect.assertions(3);

    const errorCode = `uu-todo-main/${useCase}/invalidDtoIn`;

    const dtoIn = {
      listId: false,
    };

    try {
      await TestHelper.executePostCommand(useCase, dtoIn);
    } catch (e) {
      expect(e.status).toEqual(400);
      expect(e.code).toEqual(errorCode);
      expect(e.dtoOut.uuAppErrorMap).toBeDefined();
    }
  });

  test("List does not exist", async () => {
    expect.assertions(3);
    const dtoIn = {
      listId: "60e344c9481a5a2ce8401f55",
      text: "some text",
    };

    const errorCode = `uu-todo-main/${useCase}/listDoesNotExist`;

    try {
      await TestHelper.executePostCommand(useCase, dtoIn);
    } catch (e) {
      expect(e.status).toEqual(400);
      expect(e.code).toEqual(errorCode);
      expect(e.dtoOut.uuAppErrorMap).toBeDefined();
    }
  });
});
