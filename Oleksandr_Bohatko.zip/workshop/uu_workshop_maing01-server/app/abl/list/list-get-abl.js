"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/list-error");

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Get.UC_CODE}unsupportedKeys`
  }
};

class ListAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("list");
  }

  async get(awid, dtoIn) {
      // hds 2, 2.1
      let validationResult = this.validator.validate("listGetDtoInType", dtoIn);
      // hds 2.2, 2.3, A4, A5
      let uuAppErrorMap = ValidationHelper.processValidationResult(
        dtoIn,
        validationResult,
        WARNINGS.unsupportedKeys.code,
        Errors.Get.InvalidDtoIn
      );
  
      // hds 3
      let list = await this.dao.get(awid, dtoIn.id);
      if (!list) {
        // A6
        throw new Errors.Get.ListDoesNotExist(uuAppErrorMap, { listId: dtoIn.id });
      }
  
      // hds 4
      list.uuAppErrorMap = uuAppErrorMap;
      return list;
    }

}

module.exports = new ListAbl();
