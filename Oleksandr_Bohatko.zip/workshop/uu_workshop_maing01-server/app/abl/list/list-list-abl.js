"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/list-error.js");

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.List.UC_CODE}unsupportedKeys`
  }
};
const DEFAULTS = {
  pageIndex: 0, // index of the page (default 0)
  pageSize: 1000 // max count of items per page (default 1000)
};

class ListAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("list");
  }

  async list(awid, dtoIn) {
     // hds 1, A1, hds 1.1, A2, A3
    // let jokesInstance = await jokesMain.checkInstance(
    //   awid,
    //   Errors.List.JokesInstanceDoesNotExist,
    //   Errors.List.JokesInstanceNotInProperState
    // );
    // let authorizedProfiles = authorizationResult.getAuthorizedProfiles();
    // if (
    //   jokesInstance.state === jokesMain.STATE_UNDER_CONSTRUCTION &&
    //   !authorizedProfiles.includes(jokesMain.AUTHORITIES) &&
    //   !authorizedProfiles.includes(jokesMain.EXECUTIVES)
    // ) {
    //   throw new Errors.List.JokesInstanceIsUnderConstruction({}, {state: jokesInstance.state});
    // }
    // hds 2, 2.1
    let validationResult = this.validator.validate("listListDtoInType", dtoIn);
    // hds 2.2, 2.3, A4, A5
    let uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.List.InvalidDtoIn
    );
    // hds 2.4
    /* dtoIn.pageInfo = dtoIn.pageInfo || {};
    dtoIn.pageInfo.pageSize = dtoIn.pageInfo.pageSize || DEFAULTS.pageSize;
  dtoIn.pageInfo.pageIndex = dtoIn.pageInfo.pageIndex || DEFAULTS.pageIndex;  */ 
  
    const filter = {
      awid,
      ...dtoIn,
    };
    if (!dtoIn.pageInfo) dtoIn.pageInfo = DEFAULTS.pageInfo;
    // hds 3
        let dtoOut = await this.dao.list({awid}, dtoIn.pageInfo);

    // let dtoOut = await this.dao.list(filter, dtoIn.pageInfo);

    // hds 4
    return {...dtoOut, uuAppErrorMap};
  
  }

}

module.exports = new ListAbl();
