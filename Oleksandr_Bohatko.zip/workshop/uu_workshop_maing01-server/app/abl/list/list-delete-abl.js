"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/list-error");
const workshopMain = require("../workshop-main-abl");

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Delete.UC_CODE}unsupportedKeys`
  }
};

class ListAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("list");
  }

  async delete(awid, dtoIn) {
    // hds 1, A1, hds 1.1, A2
    // await workshopMain.checkInstance(
    //   awid,
    //   Errors.Delete.ListInstanceDoesNotExist,
    //   Errors.Delete.ListInstanceNotInProperState
    // );

    // hds 2, 2.1
    let validationResult = this.validator.validate("listDeleteDtoInType", dtoIn);
    // hds 2.2, 2.3, A3, A4
    let uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.Delete.InvalidDtoIn
    );

    // hds 3
    let list = await this.dao.get(awid, dtoIn.id);
    // A5
    if (!list) {
      throw new Errors.Delete.ListDoesNotExist({ uuAppErrorMap }, { listId: dtoIn.id });
    }

    // hds 4, A6
    // if (
    //   session.getIdentity().getUuIdentity() !== list.uuIdentity &&
    //   !authorizationResult.getAuthorizedProfiles().includes("Authorities")
    // ) {
    //   throw new Errors.Delete.UserNotAuthorized({ uuAppErrorMap });
    // }

    // hds 7
    await this.dao.delete(awid, dtoIn.id);

    // hds 8
    return { uuAppErrorMap };
  }
  
}

module.exports = new ListAbl();
