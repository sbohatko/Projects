"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/item-error.js");

// 1) add deletyMany method to ItemMongo;
// 2) add HDS2 to list/delete (listWasNotFound);
// 3) item/create - swap HDS 2 <---> HDS 3;
// 4) item/update & list/update - add HDS with check if item or list exist;
// 5) add listByList method to ItemMongo;

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Create.UC_CODE}unsupportedKeys`,
  },
};

class ItemAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("item");
  }

  async create(awid, dtoIn, uuAppErrorMap = {}) {
    // hds 2, hds 2.1 A3
    let validationResult = this.validator.validate("itemCreateDtoInType", dtoIn);
    uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.Create.InvalidDtoIn
    );
      dtoIn["completed"] = false;
    let dtoOut;

    
    try {
      dtoOut = await this.dao.create({...dtoIn, awid});
    } catch (e) {
      throw new Errors.Create.ItemDaoCreateFailed(uuAppErrorMap, {dtoIn, cause: e})
    }

    return { ...dtoOut, uuAppErrorMap };
  
  }

}



module.exports = new ItemAbl();
