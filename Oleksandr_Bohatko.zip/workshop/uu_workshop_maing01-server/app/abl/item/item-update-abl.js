"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/item-error.js");

// 1) add deletyMany method to ItemMongo;
// 2) add HDS2 to list/delete (listWasNotFound);
// 3) item/create - swap HDS 2 <---> HDS 3;
// 4) item/update & list/update - add HDS with check if item or list exist;
// 5) add listByList method to ItemMongo;

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Update.UC_CODE}unsupportedKeys`,
  },
};

class ItemAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("item");
  }
  async update(awid, dtoIn) {
     // hds 1, A1, hds 1.1, A2


    // hds 2, 2.1
    let validationResult = this.validator.validate("itemUpdateDtoInType", dtoIn);
    // hds 2.2, 2.3, A3, A4
    let uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.Update.InvalidDtoIn
    );

    // hds 3
    let item = await this.dao.get(awid, dtoIn.id);
    // A5
    // if (!item) {
    //   throw new Errors.Update.ItemDoesNotExist({ uuAppErrorMap }, { itemId: dtoIn.id });
    // }

    // hds 7
      dtoIn.awid = awid;
      item = await this.dao.update(dtoIn);
    
    // hds 8
    item.uuAppErrorMap = uuAppErrorMap;
    return item;
  }

}



module.exports = new ItemAbl();
