"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/item-error.js");
const workshopMain = require("../workshop-main-abl");

// 1) add deletyMany method to ItemMongo;
// 2) add HDS2 to list/delete (listWasNotFound);
// 3) item/create - swap HDS 2 <---> HDS 3;
// 4) item/update & list/update - add HDS with check if item or list exist;
// 5) add listByList method to ItemMongo;

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Delete.UC_CODE}unsupportedKeys`,
  },
};

class ItemAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("item");
  }

  async delete(awid, dtoIn) {
    // hds 1, A1, hds 1.1, A2
    // await workshopMain.checkInstance(
    //   awid,
    //   Errors.Delete.ItemInstanceDoesNotExist,
    //   Errors.Delete.ItemInstanceNotInProperState
    // );

    // hds 2, 2.1
    let validationResult = this.validator.validate("itemDeleteDtoInType", dtoIn);
    // hds 2.2, 2.3, A3, A4
    let uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.Delete.InvalidDtoIn
    );

    // hds 3
    let item = await this.dao.get(awid, dtoIn.id);
    // A5
    if (!item) {
      throw new Errors.Delete.ItemDoesNotExist({ uuAppErrorMap }, { itemId: dtoIn.id });
    }

    // hds 4, A6
    if (
      session.getIdentity().getUuIdentity() !== item.uuIdentity &&
      !authorizationResult.getAuthorizedProfiles().includes("Authorities")
    ) {
      throw new Errors.Delete.UserNotAuthorized({ uuAppErrorMap });
    }

    // hds 7
    await this.dao.delete(awid, dtoIn.id);

    // hds 8
    return { uuAppErrorMap };
  
  }

}



module.exports = new ItemAbl();
