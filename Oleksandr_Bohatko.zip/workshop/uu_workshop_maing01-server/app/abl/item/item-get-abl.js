"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/item-error.js");

// 1) add deletyMany method to ItemMongo;
// 2) add HDS2 to list/delete (listWasNotFound);
// 3) item/create - swap HDS 2 <---> HDS 3;
// 4) item/update & list/update - add HDS with check if item or list exist;
// 5) add listByList method to ItemMongo;

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Get.UC_CODE}unsupportedKeys`,
  },
};

class ItemAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("item");
  }
  async get(awid, dtoIn) {
    // hds 2, 2.1
    let validationResult = this.validator.validate("itemGetDtoInType", dtoIn);
    // hds 2.2, 2.3, A4, A5
    let uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.Get.InvalidDtoIn
    );

    // hds 3
    let item = await this.dao.get(awid, dtoIn.id);
    if (!item) {
      // A6
      throw new Errors.Get.ItemDoesNotExist(uuAppErrorMap, { itemId: dtoIn.id });
    }

    // hds 4
    item.uuAppErrorMap = uuAppErrorMap;
    return item;
  }

}



module.exports = new ItemAbl();
