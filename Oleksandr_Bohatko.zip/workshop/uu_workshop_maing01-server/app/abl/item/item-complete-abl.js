"use strict";
const { Validator } = require("uu_appg01_server").Validation;
const { DaoFactory } = require("uu_appg01_server").ObjectStore;
const { ValidationHelper } = require("uu_appg01_server").AppServer;
const Errors = require("../../api/errors/item-error.js");

// 1) add deletyMany method to ItemMongo;
// 2) add HDS2 to list/delete (listWasNotFound);
// 3) item/create - swap HDS 2 <---> HDS 3;
// 4) item/update & list/update - add HDS with check if item or list exist;
// 5) add listByList method to ItemMongo;

const WARNINGS = {
  unsupportedKeys: {
    code: `${Errors.Complete.UC_CODE}unsupportedKeys`,
  },
};

class ItemAbl {

  constructor() {
    this.validator = Validator.load();
    this.dao = DaoFactory.getDao("item");
  }

  async complete(awid, dtoIn) {
    let validationResult = this.validator.validate("listListDtoInType", dtoIn);
    // hds 2.2, 2.3, A4, A5
    let uuAppErrorMap = ValidationHelper.processValidationResult(
      dtoIn,
      validationResult,
      WARNINGS.unsupportedKeys.code,
      Errors.List.InvalidDtoIn
    );
    let completed = dtoIn.completed ? dtoIn.completed : false;
    dtoIn.completed = completed
    let uuObject = {
      ...dtoIn
    }
    // let dtoOut = await this.dao.update(filter, dtoIn.pageInfo);

    return {uuObject, uuAppErrorMap};
  }

}



module.exports = new ItemAbl();
