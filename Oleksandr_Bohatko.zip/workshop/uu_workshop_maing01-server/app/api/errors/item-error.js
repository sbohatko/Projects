"use strict";

const WorkshopMainUseCaseError = require("./workshop-main-use-case-error");
const ITEM_ERROR_PREFIX = `${WorkshopMainUseCaseError.ERROR_PREFIX}item/`;

const Create = {
  UC_CODE: `${ITEM_ERROR_PREFIX}create/`,
  ItemDaoCreateFailed: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Create.UC_CODE}itemDaoCreateFailed`;
      this.message = "JCreate item by item DAO create failed.";
    }
  },

  ItemInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Create.UC_CODE}itemInstanceNotInProperState`;
      this.message = "itemInstance is not in proper state.";
    }
  },

  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Create.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  }
};

const Get = {
  UC_CODE: `${ITEM_ERROR_PREFIX}get/`,
  ItemInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}itemInstanceDoesNotExist`;
      this.message = "itemInstance does not exist.";
    }
  },
  ItemInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}itemInstanceNotInProperState`;
      this.message = "ItemInstance is not in proper state";
    }
  },
  ItemInstanceIsUnderConstruction: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}itemInstanceIsUnderConstruction`;
      this.message = "ItemInstance is in underConstruction state.";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ItemDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}itemDoesNotExist`;
      this.message = "Item does not exist.";
    }
  }
  
};

const Delete = {
  UC_CODE: `${ITEM_ERROR_PREFIX}delete/`,
  ItemInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceDoesNotExist`;
      this.message = "ItemInstance does not exist.";
    }
  },
  ItemInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceNotInProperState`;
      this.message = "ItemInstance is not in proper state";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ItemDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDoesNotExist`;
      this.message = "Item does not exist.";
    }
  },
  UserNotAuthorized: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}userNotAuthorized`;
      this.message = "User not authorized.";
    }
  },
  
};

const Update = {
  UC_CODE: `${ITEM_ERROR_PREFIX}update/`,
  ItemInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceDoesNotExist`;
      this.message = "ItemInstance does not exist.";
    }
  },
  ItemInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceNotInProperState`;
      this.message = "ItemInstance is not in proper state";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ItemDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDoesNotExist`;
      this.message = "Item does not exist.";
    }
  },
  UserNotAuthorized: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}userNotAuthorized`;
      this.message = "User not authorized.";
    }
  },
  ItemDaoUpdateFailed: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDaoUpdateFailed`;
      this.message = "Update item by item Dao update failed.";
    }
  },
  
};

const Complete = {
  UC_CODE: `${ITEM_ERROR_PREFIX}complete/`,
  ItemInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceDoesNotExist`;
      this.message = "ItemInstance does not exist.";
    }
  },
  ItemInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceNotInProperState`;
      this.message = "ItemInstance is not in proper state";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ItemDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDoesNotExist`;
      this.message = "Item does not exist.";
    }
  },
  UserNotAuthorized: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}userNotAuthorized`;
      this.message = "User not authorized.";
    }
  },
  ItemDaoUpdateFailed: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDaoUpdateFailed`;
      this.message = "Update item by item Dao update failed.";
    }
  },
};

const List = {
  UC_CODE: `${ITEM_ERROR_PREFIX}list/`,
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ItemInstanceIsUnderConstruction: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceIsUnderConstruction`;
      this.message = "ItemInstance is in state underConstruction.";
    }
  },
  ItemInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceDoesNotExist`;
      this.message = "ItemInstance does not exist.";
    }
  },
  ItemInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemInstanceNotInProperState`;
      this.message = "ItemInstance is not in proper state";
    }
  },
};

module.exports = {
  List,
  Complete,
  Update,
  Delete,
  Get,
  Create
};
