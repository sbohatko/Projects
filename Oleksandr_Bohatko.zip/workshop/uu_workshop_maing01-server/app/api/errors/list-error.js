"use strict";

const WorkshopMainUseCaseError = require("./workshop-main-use-case-error.js");
const LIST_ERROR_PREFIX = `${WorkshopMainUseCaseError.ERROR_PREFIX}list/`;

const Create = {
  UC_CODE: `${LIST_ERROR_PREFIX}create/`,
  ListDaoCreateFailed: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Create.UC_CODE}listDaoCreateFailed`;
      this.message = "JCreate list by list DAO create failed.";
    }
 
  },
  ListInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Create.UC_CODE}ListInstanceNotInProperState`;
      this.message = "ListInstance is not in proper state.";
    }
  },

  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Create.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  }
};

const Get = {
  UC_CODE: `${LIST_ERROR_PREFIX}get/`,
  ListInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}listInstanceDoesNotExist`;
      this.message = "ListInstance does not exist.";
    }
  },
  ListInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}listInstanceNotInProperState`;
      this.message = "ListInstance is not in proper state";
    }
  },
  ListInstanceIsUnderConstruction: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}listInstanceIsUnderConstruction`;
      this.message = "ListInstance is in underConstruction state.";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ListDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${Get.UC_CODE}listDoesNotExist`;
      this.message = "List does not exist.";
    }
  }
};

const Delete = {
  UC_CODE: `${LIST_ERROR_PREFIX}delete/`,
  ListInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceDoesNotExist`;
      this.message = "ListInstance does not exist.";
    }
  },
  ListInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceNotInProperState`;
      this.message = "ListInstance is not in proper state";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ListDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}ListDoesNotExist`;
      this.message = "List does not exist.";
    }
  },
  UserNotAuthorized: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}userNotAuthorized`;
      this.message = "User not authorized.";
    }
  },
};

const Update = {
  UC_CODE: `${LIST_ERROR_PREFIX}update/`,
  ListInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceDoesNotExist`;
      this.message = "ListInstance does not exist.";
    }
  },
  ListInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceNotInProperState`;
      this.message = "ListInstance is not in proper state";
    }
  },
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ListDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDoesNotExist`;
      this.message = "Item does not exist.";
    }
  },
  UserNotAuthorized: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}userNotAuthorized`;
      this.message = "User not authorized.";
    }
  },
  ListDaoUpdateFailed: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}itemDaoUpdateFailed`;
      this.message = "Update item by item Dao update failed.";
    }
  },
};

const List = {
  UC_CODE: `${LIST_ERROR_PREFIX}list/`,
  InvalidDtoIn: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}invalidDtoIn`;
      this.message = "DtoIn is not valid.";
    }
  },
  ListInstanceIsUnderConstruction: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceIsUnderConstruction`;
      this.message = "ListInstance is in state underConstruction.";
    }
  },
  ListInstanceDoesNotExist: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceDoesNotExist`;
      this.message = "ListInstance does not exist.";
    }
  },
  ListInstanceNotInProperState: class extends WorkshopMainUseCaseError {
    constructor() {
      super(...arguments);
      this.code = `${List.UC_CODE}listInstanceNotInProperState`;
      this.message = "ListInstance is not in proper state";
    }
  },
};

module.exports = {
  List,
  Update,
  Delete,
  Get,
  Create
};
