"use strict";
const ListGetAbl = require("../../abl/list/list-get-abl.js");
const ListListAbl = require("../../abl/list/list-list-abl.js");
const ListUpdateAbl = require("../../abl/list/list-update-abl.js");
const ListDeleteAbl = require("../../abl/list/list-delete-abl.js");
const ListCreateAbl = require("../../abl/list/list-create-abl.js");


class ListController {

  list(ucEnv) {
    return ListListAbl.list(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  update(ucEnv) {
    return ListUpdateAbl.update(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  delete(ucEnv) {
    return ListDeleteAbl.delete(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  get(ucEnv) {
    return ListGetAbl.get(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  create(ucEnv) {
    return ListCreateAbl.create(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

}

module.exports = new ListController();
