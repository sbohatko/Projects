"use strict";
const ItemListAbl = require("../../abl/item/item-list-abl.js");
const ItemCompleteAbl = require("../../abl/item/item-complete-abl.js");
const ItemUpdateAbl = require("../../abl/item/item-update-abl.js");
const ItemDeleteAbl = require("../../abl/item/item-delete-abl.js");
const ItemGetAbl = require("../../abl/item/item-get-abl.js");
const ItemCreateAbl = require("../../abl/item/item-create-abl.js");

class ItemController {

  list(ucEnv) {
    return ItemListAbl.list(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  complete(ucEnv) {
    return ItemCompleteAbl.complete(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  update(ucEnv) {
    return ItemUpdateAbl.update(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  delete(ucEnv) {
    return ItemDeleteAbl.delete(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  get(ucEnv) {
    return ItemGetAbl.get(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

  create(ucEnv) {
    return ItemCreateAbl.create(ucEnv.getUri().getAwid(), ucEnv.getDtoIn());
  }

}

module.exports = new ItemController();
