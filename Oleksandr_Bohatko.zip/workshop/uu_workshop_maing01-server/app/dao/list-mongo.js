"use strict";
const { UuObjectDao } = require("uu_appg01_server").ObjectStore;

class ListMongo extends UuObjectDao {

  async createSchema(){}

  async create(uuObject) {
    return await super.insertOne(uuObject);
  };
  async get(awid, id) {
    return await super.findOne({awid ,id});
  };
  async update(uuObject) {
    if (uuObject.categoryList) {
      uuObject.categoryList = uuObject.categoryList.map(categoryId => new ObjectId(categoryId));
    }
    let filter = { id: uuObject.id, awid: uuObject.awid };
    return await super.findOneAndUpdate(filter, uuObject, "NONE");
  };

  async delete(awid, id,forceDelete = null) {
    await super.deleteOne({ awid, id },forceDelete);
  };
  async list(awid, pageInfo = {}) {
    return await super.find(awid, pageInfo);
  };
 

}

module.exports = ListMongo;
