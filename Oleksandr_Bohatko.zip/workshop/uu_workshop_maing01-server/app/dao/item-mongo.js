"use strict";
const { UuObjectDao } = require("uu_appg01_server").ObjectStore;

class ItemMongo extends UuObjectDao {

  async createSchema(){}
  
  async create(uuObject,completed=false) {
    return await super.insertOne(uuObject,completed);
  };
  async get(awid, id) {
    return await super.findOne({ id, awid });
  };
  async update(uuObject) {
    if (uuObject.categoryList) {
      uuObject.categoryList = uuObject.categoryList.map(categoryId => new ObjectId(categoryId));
    }
    let filter = { id: uuObject.id, awid: uuObject.awid };
    return await super.findOneAndUpdate(filter, uuObject, "NONE");
  };
  
async list(filter, pageInfo = {}) {
    return await super.find(filter, pageInfo);
  }
  async delete(awid, id) {
    await super.deleteOne({ awid, id });
  };
  async deletyMany(awid, filter){
    return await super.delete(awid, filter);
  }

}

module.exports = ItemMongo;
